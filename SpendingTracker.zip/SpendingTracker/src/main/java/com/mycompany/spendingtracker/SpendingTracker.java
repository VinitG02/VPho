/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.spendingtracker;


/**
 *
 * @author Vinit
 */
public class SpendingTracker {

//    public static void main(String[] args) {
//       JOptionPane JOptionPane = new JOptionPane();
//    }
}
